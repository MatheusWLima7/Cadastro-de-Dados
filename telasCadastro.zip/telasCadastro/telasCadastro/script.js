document.addEventListener("DOMContentLoaded", () => {
  const content = document.getElementById("content");
  let editingRow = null;

  let modalCallback = null;
  const modal = document.getElementById("modalConfirm");
  const modalMessage = document.getElementById("modalMessage");
  const modalClose = document.getElementById("modalClose");
  const modalCancel = document.getElementById("modalCancel");
  const modalOk = document.getElementById("modalOk");

  function showModal(message, onConfirm) {
    modalMessage.innerText = message;
    modal.style.display = "flex";
    modalCallback = onConfirm;
  }

  function closeModal() {
    modal.style.display = "none";
    modalCallback = null;
  }

  modalClose.onclick = closeModal;
  modalCancel.onclick = closeModal;
  modalOk.onclick = () => {
    if (modalCallback) modalCallback();
    closeModal();
  };

  function formatCurrency(value) {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL"
    }).format(value);
  }

  function parseCurrency(value) {
    let cleaned = value.replace(/[^\d,.]/g, "");
    cleaned = cleaned.replace(/\./g, "");
    cleaned = cleaned.replace(",", ".");
    return parseFloat(cleaned);
  }

  function resetForm(formId) {
    const form = document.getElementById(formId);
    if (form) form.reset();
  }

  function addRow(tableId, cells, type) {
    const table = document.getElementById(tableId).querySelector("tbody");
    const row = `<tr data-type="${type}">
      ${cells.map(cell => `<td>${cell}</td>`).join('')}
      <td class="actions">
        <i class="fas fa-edit" onclick="editRow(this)"></i>
        <i class="fas fa-trash" onclick="deleteRow(this)"></i>
      </td>
    </tr>`;
    table.innerHTML += row;
  }

  const pages = {
    agencia: `
      <div class="container">
        <h1>Cadastro de Agência</h1>
        <form id="agenciaForm">
          <input type="text" id="agenciaNome" placeholder="Nome da Agência*" required>
          <input type="text" id="agenciaCidade" placeholder="Cidade" required>
          <input type="number" id="ativos" placeholder="Ativos" required>
          <button type="button" onclick="saveAgencia()">Salvar</button>
        </form>
        <h2>Agências Cadastradas</h2>
        <table id="agenciaTable">
          <thead>
            <tr>
              <th>Nome</th>
              <th>Cidade</th>
              <th>Ativos</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody></tbody>
        </table>
      </div>
    `,
    cliente: `
      <div class="container">
        <h1>Cadastro de Cliente</h1>
        <form id="clienteForm">
          <input type="text" id="clienteNome" placeholder="Nome do Cliente*" required>
          <input type="text" id="clienteEndereco" placeholder="Endereço" required>
          <input type="text" id="clienteCidade" placeholder="Cidade" required>
          <button type="button" onclick="saveCliente()">Salvar</button>
        </form>
        <h2>Clientes Cadastrados</h2>
        <table id="clienteTable">
          <thead>
            <tr>
              <th>Nome</th>
              <th>Endereço</th>
              <th>Cidade</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody></tbody>
        </table>
      </div>
    `,
    conta: `
      <div class="container">
        <h1>Cadastro de Conta</h1>
        <form id="contaForm">
          <input type="text" id="agenciaNomeConta" placeholder="Nome da Agência*" required>
          <input type="text" id="clienteNomeConta" placeholder="Nome do Cliente*" required>
          <input type="text" id="contaNumero" placeholder="Número da Conta*" required>
          <input type="number" id="saldo" placeholder="Saldo" required>
          <button type="button" onclick="saveConta()">Salvar</button>
        </form>
        <h2>Contas Cadastradas</h2>
        <table id="contaTable">
          <thead>
            <tr>
              <th>Agência</th>
              <th>Cliente</th>
              <th>Número</th>
              <th>Saldo</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody></tbody>
        </table>
      </div>
    `
  };

  window.navigateTo = (page) => {
    content.classList.add("fade-out");
    setTimeout(() => {
      content.innerHTML = pages[page];
      content.classList.remove("fade-out");
    }, 300);
  };

  window.saveAgencia = () => {
    const nome = document.getElementById("agenciaNome").value;
    const cidade = document.getElementById("agenciaCidade").value;
    const ativos = document.getElementById("ativos").value;

    if (!nome || !cidade || !ativos) {
      alert("Preencha todos os campos!");
      return;
    }

    const ativosValue = parseFloat(ativos);
    if (isNaN(ativosValue)) {
      alert("Ativos deve ser um número!");
      return;
    }

    const cells = [nome, cidade, formatCurrency(ativosValue)];

    if (editingRow) {
      editingRow.cells[0].innerText = nome;
      editingRow.cells[1].innerText = cidade;
      editingRow.cells[2].innerText = formatCurrency(ativosValue);
      editingRow = null;
    } else {
      addRow("agenciaTable", cells, "agencia");
    }

    resetForm("agenciaForm");
  };

  window.saveCliente = () => {
    const nome = document.getElementById("clienteNome").value;
    const endereco = document.getElementById("clienteEndereco").value;
    const cidade = document.getElementById("clienteCidade").value;

    if (!nome || !endereco || !cidade) {
      alert("Preencha todos os campos!");
      return;
    }

    const cells = [nome, endereco, cidade];

    if (editingRow) {
      editingRow.cells[0].innerText = nome;
      editingRow.cells[1].innerText = endereco;
      editingRow.cells[2].innerText = cidade;
      editingRow = null;
    } else {
      addRow("clienteTable", cells, "cliente");
    }

    resetForm("clienteForm");
  };

  window.saveConta = () => {
    const agencia = document.getElementById("agenciaNomeConta").value;
    const cliente = document.getElementById("clienteNomeConta").value;
    const numero = document.getElementById("contaNumero").value;
    const saldo = document.getElementById("saldo").value;

    if (!agencia || !cliente || !numero || !saldo) {
      alert("Preencha todos os campos!");
      return;
    }

    const saldoValue = parseFloat(saldo);
    if (isNaN(saldoValue)) {
      alert("Saldo deve ser um número!");
      return;
    }

    const cells = [agencia, cliente, numero, formatCurrency(saldoValue)];

    if (editingRow) {
      editingRow.cells[0].innerText = agencia;
      editingRow.cells[1].innerText = cliente;
      editingRow.cells[2].innerText = numero;
      editingRow.cells[3].innerText = formatCurrency(saldoValue);
      editingRow = null;
    } else {
      addRow("contaTable", cells, "conta");
    }

    resetForm("contaForm");
  };

  window.editRow = (icon) => {
    const row = icon.closest("tr");
    const type = row.getAttribute("data-type");
    const cells = row.querySelectorAll("td");

    showModal("Tem certeza que deseja editar?", () => {
      editingRow = row;
      if (type === "agencia") {
        document.getElementById("agenciaNome").value = cells[0].innerText;
        document.getElementById("agenciaCidade").value = cells[1].innerText;
        document.getElementById("ativos").value = parseCurrency(cells[2].innerText);
      } else if (type === "cliente") {
        document.getElementById("clienteNome").value = cells[0].innerText;
        document.getElementById("clienteEndereco").value = cells[1].innerText;
        document.getElementById("clienteCidade").value = cells[2].innerText;
      } else if (type === "conta") {
        document.getElementById("agenciaNomeConta").value = cells[0].innerText;
        document.getElementById("clienteNomeConta").value = cells[1].innerText;
        document.getElementById("contaNumero").value = cells[2].innerText;
        document.getElementById("saldo").value = parseCurrency(cells[3].innerText);
      }
    });
  };

  window.deleteRow = (icon) => {
    showModal("Tem certeza que deseja excluir este item?", () => {
      icon.closest("tr").remove();
    });
  };

  navigateTo("agencia");
});